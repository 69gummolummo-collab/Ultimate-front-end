# Thor Frontend (v0.1, untested)
## Build the APK (no PC toolchain needed)
1. Create a GitHub repo, upload this folder's contents, push.
2. Actions tab -> "Build APK" -> download artifact `ThorFrontend-apk` -> unzip -> install app-debug.apk.
(Or open in Android Studio and Run.)
## Set up
- Press Home -> choose "Thor Frontend" -> **Always**. That makes it the launcher, so it starts on power-on.
- Games -> "Add ROM folder" -> pick folder -> pick its system.
- Edit `SYSTEMS` in Model.kt to match your emulators' package/activity.
- Bottom screen launches automatically on the second display.
