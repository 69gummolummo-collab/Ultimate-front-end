package com.thor.frontend

import android.app.Activity
import android.app.ActivityOptions
import android.app.AlertDialog
import android.content.Intent
import android.hardware.*
import android.hardware.display.DisplayManager
import android.os.Bundle
import android.view.*

class MainActivity : Activity(), SensorEventListener {
    private lateinit var v: HomeView
    private var roms = listOf<Item>(); private var apps = listOf<Item>()
    private var lastNav = 0L; private var lastCompanion = 0L

    override fun onCreate(b: Bundle?) {
        super.onCreate(b); immersive(window)
        v = HomeView(this).also { setContentView(it) }
        v.folders = listOf(Item("Games", "folder", glyph = "🎮"), Item("Apps", "folder", glyph = "📱"), Item("System", "folder", glyph = "⚙️"))
        v.kidsFor = { when (it) { 0 -> roms + Item("Add ROM folder", "add", glyph = "➕"); 1 -> apps; else -> Lib.system() } }
        v.onLaunch = { if (it.kind == "add") startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION), 1) else Lib.launch(this, it) }
        v.onSelect = { sel ->
            Bus.last = sel; Bus.listener?.invoke(sel)
            v.kids.subList(maxOf(0, v.ki - 3), minOf(v.kids.size, v.ki + 4)).forEach {
                Lib.cover(this, it) { runOnUiThread { v.invalidate(); Bus.listener?.invoke(Bus.last) } }
            }
        }
        refresh()
    }

    private fun refresh() = Thread {
        roms = Lib.roms(this); apps = Lib.apps(this)
        runOnUiThread { if (v.openF >= 0) { v.kids = v.kidsFor(v.openF); v.invalidate() } }
    }.start()

    override fun onResume() {
        super.onResume()
        val sm = getSystemService(SensorManager::class.java)
        sm.registerListener(this, sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER), SensorManager.SENSOR_DELAY_GAME)
        if (!Bus.alive && System.currentTimeMillis() - lastCompanion > 3000) launchCompanion()
    }
    override fun onPause() { super.onPause(); getSystemService(SensorManager::class.java).unregisterListener(this) }

    /** Opens the info panel as its own activity on the Thor's second display. */
    private fun launchCompanion() {
        lastCompanion = System.currentTimeMillis()
        val d = getSystemService(DisplayManager::class.java).displays.firstOrNull { it.displayId != Display.DEFAULT_DISPLAY } ?: return
        val o = ActivityOptions.makeBasic().setLaunchDisplayId(d.displayId)
        startActivity(Intent(this, Companion::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), o.toBundle())
    }

    override fun onSensorChanged(e: SensorEvent) { // tilt parallax (low-passed accelerometer)
        v.tx += (-e.values[0] * 4f - v.tx) * 0.1f; v.ty += (e.values[1] * 4f - v.ty) * 0.1f
    }
    override fun onAccuracyChanged(s: Sensor?, a: Int) {}

    override fun dispatchKeyEvent(e: KeyEvent): Boolean =
        if (e.action == KeyEvent.ACTION_DOWN && v.key(e.keyCode)) true else if (e.keyCode == KeyEvent.KEYCODE_BACK) true else super.dispatchKeyEvent(e)

    override fun onGenericMotionEvent(e: MotionEvent): Boolean {
        val x = e.getAxisValue(MotionEvent.AXIS_X) + e.getAxisValue(MotionEvent.AXIS_HAT_X)
        val y = e.getAxisValue(MotionEvent.AXIS_Y) + e.getAxisValue(MotionEvent.AXIS_HAT_Y)
        val now = System.currentTimeMillis()
        if (now - lastNav > 180) {
            val k = when { x > 0.6f -> KeyEvent.KEYCODE_DPAD_RIGHT; x < -0.6f -> KeyEvent.KEYCODE_DPAD_LEFT
                y > 0.6f -> KeyEvent.KEYCODE_DPAD_DOWN; y < -0.6f -> KeyEvent.KEYCODE_DPAD_UP; else -> 0 }
            if (k != 0) { v.key(k); lastNav = now }
        }
        return true
    }

    override fun onActivityResult(r: Int, res: Int, d: Intent?) {
        val uri = d?.data ?: return
        contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        val names = SYSTEMS.keys.toTypedArray()
        AlertDialog.Builder(this).setTitle("Which system is this folder?").setItems(names) { _, i ->
            Lib.addDir(this, names[i], uri); refresh()
        }.show()
    }
}
