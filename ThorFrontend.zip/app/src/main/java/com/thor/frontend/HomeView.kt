package com.thor.frontend

import android.content.Context
import android.graphics.*
import android.view.*
import kotlin.math.*

class HomeView(ctx: Context) : View(ctx) {
    var folders = listOf<Item>(); var kids = listOf<Item>()
    var openF = -1; var fi = 0; var ki = 0; var inKids = false
    var kidsFor: (Int) -> List<Item> = { emptyList() }
    var onSelect: (Item?) -> Unit = {}
    var onLaunch: (Item) -> Unit = {}
    var tx = 0f; var ty = 0f
    private val p = Paint(Paint.ANTI_ALIAS_FLAG); private val path = Path(); private val rf = RectF()
    private val t0 = System.nanoTime()
    private val stars = List(70) { floatArrayOf(rnd() * 6.28f, 0.6f + rnd() * 1.2f, rnd() * 6.28f) }
    private fun rnd() = Math.random().toFloat()
    private val s get() = height * 0.2f
    private fun fx(i: Int) = width / 2f + (i - (folders.size - 1) / 2f) * s * 1.7f + tx * 1.5f
    private fun fy() = height * 0.27f + ty * 1.5f
    private fun kx(j: Int) = width / 2f + (j - ki) * s * 1.3f + tx * 2.5f
    private fun ky() = height * 0.7f + ty * 2.5f

    fun sel() { onSelect(if (inKids) kids.getOrNull(ki) else folders.getOrNull(fi)); invalidate() }
    fun openFolder(i: Int) { fi = i; openF = i; kids = kidsFor(i); ki = 0; inKids = kids.isNotEmpty(); sel() }
    private fun close() { openF = -1; kids = emptyList(); inKids = false; sel() }
    private fun move(d: Int) {
        if (inKids) ki = (ki + d).coerceIn(0, max(0, kids.lastIndex))
        else { fi = (fi + d).coerceIn(0, folders.lastIndex); if (openF >= 0) { openFolder(fi); return } }
        sel()
    }

    fun key(k: Int): Boolean {
        when (k) {
            KeyEvent.KEYCODE_DPAD_LEFT -> move(-1)
            KeyEvent.KEYCODE_DPAD_RIGHT -> move(1)
            KeyEvent.KEYCODE_BUTTON_L1 -> move(-5)
            KeyEvent.KEYCODE_BUTTON_R1 -> move(5)
            KeyEvent.KEYCODE_DPAD_DOWN -> if (!inKids) { if (openF != fi) openFolder(fi) else if (kids.isNotEmpty()) { inKids = true; sel() } }
            KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_BUTTON_B, KeyEvent.KEYCODE_BACK ->
                if (inKids) { inKids = false; sel() } else if (openF >= 0) close()
            KeyEvent.KEYCODE_BUTTON_A, KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER ->
                if (inKids) kids.getOrNull(ki)?.let(onLaunch) else if (openF == fi) close() else openFolder(fi)
            else -> return false
        }
        return true
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.action == MotionEvent.ACTION_UP) {
            val r = s / 2 * 1.2f
            if (openF >= 0) kids.indices.firstOrNull { abs(e.x - kx(it)) < r && abs(e.y - ky()) < r }?.let { j ->
                if (inKids && j == ki) onLaunch(kids[j]) else { ki = j; inKids = true; sel() }
                return true
            }
            folders.indices.firstOrNull { abs(e.x - fx(it)) < r && abs(e.y - fy()) < r }?.let { i ->
                if (openF == i) { fi = i; close() } else openFolder(i)
                return true
            }
        }
        return true
    }

    private fun icon(c: Canvas, cx: Float, cy0: Float, it: Item, sel: Boolean, t: Float, n: Int) {
        val sz = s; val cy = cy0 + sin(t * 1.6f + n) * 3f
        if (sel) { // soft golden glow behind the shape
            p.shader = RadialGradient(cx, cy, sz * (0.95f + 0.05f * sin(t * 4)), 0xDDFFC107.toInt(), 0x00FFC107, Shader.TileMode.CLAMP)
            c.drawCircle(cx, cy, sz, p); p.shader = null
        }
        c.save(); c.translate(cx, cy); if (sel) c.rotate(sin(t * 16f) * 3f) // Vita-style jiggle
        val r = sz / 2 * (if (sel) 1.12f else 1f)
        rf.set(-r, -r, r, r)
        p.color = when (it.kind) { "folder" -> 0xFF3F7FD6.toInt(); "app" -> 0xFF444B66.toInt(); "sys" -> 0xFF2E8B6E.toInt(); "add" -> 0xFF8E5BC4.toInt(); else -> 0xFF6A4FA3.toInt() }
        c.drawRoundRect(rf, r * 0.28f, r * 0.28f, p)
        val b = Lib.covers[it.uri] ?: Lib.icons[it.pkg]
        if (b != null) {
            val m = min(b.width, b.height)
            path.reset(); path.addRoundRect(rf, r * 0.28f, r * 0.28f, Path.Direction.CW)
            c.save(); c.clipPath(path)
            c.drawBitmap(b, Rect((b.width - m) / 2, (b.height - m) / 2, (b.width + m) / 2, (b.height + m) / 2), rf, p)
            c.restore()
        } else {
            p.color = Color.WHITE; p.textAlign = Paint.Align.CENTER; p.textSize = r * 0.9f
            c.drawText(it.glyph.ifEmpty { it.title.take(2) }, 0f, r * 0.32f, p)
        }
        c.restore()
        p.color = Color.WHITE; p.textSize = sz * 0.15f; p.textAlign = Paint.Align.CENTER
        c.drawText(it.title.take(18), cx, cy + sz * 0.72f, p)
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat(); val t = (System.nanoTime() - t0) / 1e9f
        p.shader = LinearGradient(0f, 0f, 0f, h, 0xFF0B1B4D.toInt(), 0xFF2A6FB5.toInt(), Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w, h, p); p.shader = null
        for (k in 0..3) { // PS3-style waves
            path.reset(); path.moveTo(0f, h); var x = 0f
            while (x <= w + 20) {
                path.lineTo(x, h * (0.45f + 0.12f * k) + sin(x / w * 6.28f * (1.2f + k * 0.3f) + t * (0.6f + k * 0.25f)) * h * 0.05f + ty * (k + 1) * 2)
                x += 20f
            }
            path.lineTo(w, h); path.close(); p.color = Color.argb(55, 255, 255, 255); c.drawPath(path, p)
        }
        folders.forEachIndexed { i, f -> if (i != openF) icon(c, fx(i), fy(), f, !inKids && i == fi, t, i) }
        if (openF >= 0) {
            p.shader = RadialGradient(fx(openF), fy(), s * 1.4f, 0x00000000, 0xB3000000.toInt(), Shader.TileMode.CLAMP)
            c.drawRect(0f, 0f, w, h, p); p.shader = null // spotlight: everything else dims
            for (st in stars) {
                val a = st[0] + t * 0.3f; val d = s * (0.6f + st[1] * 0.5f)
                p.color = Color.argb(((sin(t * 3 + st[2]) + 1) / 2 * 255).toInt(), 255, 240, 170)
                c.drawCircle(fx(openF) + cos(a) * d, fy() + sin(a) * d, 2f + st[1] * 2f, p)
            }
            icon(c, fx(openF), fy(), folders[openF], !inKids, t, openF)
            kids.forEachIndexed { j, k -> val x = kx(j); if (x > -s && x < w + s) icon(c, x, ky(), k, inKids && j == ki, t, j) }
        }
        postInvalidateOnAnimation()
    }
}
