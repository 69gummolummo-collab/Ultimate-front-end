package com.thor.frontend

import android.annotation.SuppressLint
import android.app.Activity
import android.app.ActivityOptions
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.*
import android.text.TextUtils
import android.view.*
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import java.net.URLEncoder

/** Bottom-screen panel: info, scrolling ticker, video search, Home and screen-off buttons. */
class Companion : Activity() {
    private val h = Handler(Looper.getMainLooper())
    private lateinit var web: WebView

    @SuppressLint("SetJavaScriptEnabled", "ClickableViewAccessibility")
    override fun onCreate(b: Bundle?) {
        super.onCreate(b); Bus.alive = true; immersive(window)
        val cover = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
        val title = TextView(this).apply { setTextColor(Color.WHITE); textSize = 20f; typeface = Typeface.DEFAULT_BOLD }
        val sub = TextView(this).apply { setTextColor(0xFFAAB4D0.toInt()); textSize = 14f }
        val ticker = TextView(this).apply {
            setTextColor(0xFFFFD54F.toInt()); textSize = 16f; isSingleLine = true
            ellipsize = TextUtils.TruncateAt.MARQUEE; marqueeRepeatLimit = -1; isSelected = true; setPadding(0, 16, 0, 16)
        }
        web = WebView(this).apply {
            settings.javaScriptEnabled = true; settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false; webViewClient = WebViewClient()
        }
        val dark = View(this).apply {
            setBackgroundColor(Color.BLACK); visibility = View.GONE
            setOnTouchListener { _, e -> if (e.action == MotionEvent.ACTION_DOWN) visibility = View.GONE; true }
        }
        fun lp(w: Int, hh: Int, wt: Float = 0f) = LinearLayout.LayoutParams(w, hh, wt)
        val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; addView(title); addView(sub) }
        val top = LinearLayout(this).apply {
            addView(cover, lp(300, 300)); addView(info, lp(0, -2, 1f).apply { leftMargin = 24 })
        }
        val home = Button(this).apply { text = "⌂  Home"; setOnClickListener {
            val o = ActivityOptions.makeBasic().setLaunchDisplayId(Display.DEFAULT_DISPLAY)
            startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), o.toBundle())
        } }
        val off = Button(this).apply { text = "●  Screen off"; setOnClickListener { dark.visibility = View.VISIBLE } }
        val bar = LinearLayout(this).apply { addView(home, lp(0, -2, 1f)); addView(off, lp(0, -2, 1f)) }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(24, 24, 24, 24)
            addView(top); addView(ticker); addView(web, lp(-1, 0, 1f)); addView(bar)
        }
        setContentView(FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK); addView(col); addView(dark, FrameLayout.LayoutParams(-1, -1))
        })

        var lastQ = ""
        fun show(x: Item?) {
            if (x == null) return
            title.text = x.title
            sub.text = when (x.kind) { "rom" -> x.system; "app" -> "App"; "folder" -> "Folder"; else -> "System" }
            cover.setImageBitmap(Lib.covers[x.uri] ?: Lib.icons[x.pkg])
            ticker.text = "${x.title}  •  ${sub.text}  •  " + (if (x.kind == "rom") "Press A to launch in its emulator" else "Press A to open") + "  •  "
            val q = x.title + " " + x.system + " gameplay"
            if (x.kind == "rom" || x.kind == "app") {
                h.removeCallbacksAndMessages(null)
                h.postDelayed({ if (q != lastQ) { lastQ = q; web.loadUrl("https://m.youtube.com/results?search_query=" + URLEncoder.encode(q, "UTF-8")) } }, 900)
            }
        }
        Bus.listener = { show(it) }; show(Bus.last)
    }

    override fun onDestroy() { Bus.alive = false; Bus.listener = null; web.destroy(); super.onDestroy() }
}
