package com.thor.frontend

import android.content.*
import android.graphics.*
import android.graphics.drawable.Drawable
import android.net.Uri
import android.provider.Settings
import android.view.*
import android.widget.Toast
import androidx.documentfile.provider.DocumentFile
import java.io.File
import java.net.URL
import java.net.URLEncoder

data class Emu(val pkg: String, val cls: String?, val thumbs: String)
data class Item(val title: String, val kind: String, val system: String = "", val uri: String = "",
                val pkg: String = "", val action: String = "", val glyph: String = "")

/** System -> emulator. EDIT THESE to match what you have installed (package, activity, libretro thumbnail folder). */
val SYSTEMS = linkedMapOf(
    "Nintendo DS" to Emu("com.dsemu.drastic", "com.dsemu.drastic.DraStic", "Nintendo - Nintendo DS"),
    "PSP" to Emu("org.ppsspp.ppsspp", "org.ppsspp.ppsspp.PpssppActivity", "Sony - PlayStation Portable"),
    "PS2" to Emu("xyz.aethersx2.android", "xyz.aethersx2.android.EmulationActivity", "Sony - PlayStation 2"),
    "SNES" to Emu("com.explusalpha.Snes9xPlus", null, "Nintendo - Super Nintendo Entertainment System"),
    "GBA" to Emu("com.fastemulator.gbapro", null, "Nintendo - Game Boy Advance")
)

object Bus { var listener: ((Item?) -> Unit)? = null; var alive = false; var last: Item? = null }

fun immersive(w: Window) {
    w.setDecorFitsSystemWindows(false)
    w.insetsController?.let {
        it.hide(WindowInsets.Type.systemBars())
        it.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
    }
    w.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
}

object Lib {
    val covers = HashMap<String, Bitmap?>()
    val icons = HashMap<String, Bitmap>()
    private val SKIP = setOf("jpg", "png", "txt", "xml", "srm", "sav", "state", "dsv", "cfg", "ini", "json", "db", "bak")
    private fun prefs(c: Context) = c.getSharedPreferences("lib", 0)

    fun addDir(c: Context, system: String, uri: Uri) {
        val s = prefs(c).getStringSet("dirs", emptySet())!!.toMutableSet()
        s.add("$system|$uri"); prefs(c).edit().putStringSet("dirs", s).apply()
    }

    private fun walk(d: DocumentFile, depth: Int, out: MutableList<DocumentFile>) {
        for (f in d.listFiles()) if (f.isDirectory) { if (depth < 3) walk(f, depth + 1, out) } else if (f.isFile) out.add(f)
    }

    fun roms(c: Context): List<Item> {
        val out = mutableListOf<Item>()
        for (e in prefs(c).getStringSet("dirs", emptySet())!!) {
            val (sys, u) = e.split("|", limit = 2)
            val root = DocumentFile.fromTreeUri(c, Uri.parse(u)) ?: continue
            val files = mutableListOf<DocumentFile>(); walk(root, 0, files)
            files.filter { (it.name ?: "").substringAfterLast('.', "").lowercase() !in SKIP }
                .forEach { out.add(Item((it.name ?: "?").substringBeforeLast('.'), "rom", sys, it.uri.toString())) }
        }
        return out.sortedBy { it.title.lowercase() }
    }

    private fun bmp(d: Drawable): Bitmap {
        val b = Bitmap.createBitmap(160, 160, Bitmap.Config.ARGB_8888)
        d.setBounds(0, 0, 160, 160); d.draw(Canvas(b)); return b
    }

    fun apps(c: Context): List<Item> {
        val pm = c.packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(i, 0).filter { it.activityInfo.packageName != c.packageName }
            .sortedBy { it.loadLabel(pm).toString().lowercase() }
            .map { r ->
                val pk = r.activityInfo.packageName
                if (!icons.containsKey(pk)) icons[pk] = bmp(r.loadIcon(pm))
                Item(r.loadLabel(pm).toString(), "app", pkg = pk)
            }
    }

    fun system() = listOf(
        Item("Wi-Fi", "sys", action = "android.settings.panel.action.WIFI", glyph = "📶"),
        Item("Bluetooth", "sys", action = Settings.ACTION_BLUETOOTH_SETTINGS, glyph = "🔵"),
        Item("Volume", "sys", action = "android.settings.panel.action.VOLUME", glyph = "🔊"),
        Item("Display", "sys", action = Settings.ACTION_DISPLAY_SETTINGS, glyph = "🔆"),
        Item("Storage", "sys", action = Settings.ACTION_INTERNAL_STORAGE_SETTINGS, glyph = "💾"),
        Item("Settings", "sys", action = Settings.ACTION_SETTINGS, glyph = "⚙️")
    )

    /** Box art from the libretro thumbnail server (No-Intro style file names match best). */
    fun cover(c: Context, it: Item, done: () -> Unit) {
        if (it.kind != "rom" || covers.containsKey(it.uri)) return
        covers[it.uri] = null
        Thread {
            val f = File(c.cacheDir, "cv_" + it.uri.hashCode())
            try {
                if (!f.exists()) {
                    fun enc(s: String) = URLEncoder.encode(s, "UTF-8").replace("+", "%20")
                    val n = it.title.replace(Regex("[&*/:`<>?\\\\|\"]"), "_")
                    URL("https://thumbnails.libretro.com/${enc(SYSTEMS[it.system]!!.thumbs)}/Named_Boxarts/${enc(n)}.png")
                        .openStream().use { i -> f.outputStream().use { o -> i.copyTo(o) } }
                }
                covers[it.uri] = BitmapFactory.decodeFile(f.path)
                done()
            } catch (e: Exception) { f.delete() }
        }.start()
    }

    fun launch(c: Context, it: Item) {
        try {
            val i = when (it.kind) {
                "rom" -> {
                    val e = SYSTEMS[it.system]!!
                    Intent(Intent.ACTION_VIEW).setDataAndType(Uri.parse(it.uri), "*/*").apply {
                        if (e.cls != null) setClassName(e.pkg, e.cls) else setPackage(e.pkg)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                }
                "app" -> c.packageManager.getLaunchIntentForPackage(it.pkg)!!
                else -> Intent(it.action)
            }
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); c.startActivity(i)
        } catch (e: Exception) { Toast.makeText(c, "Couldn't launch: ${e.message}", Toast.LENGTH_LONG).show() }
    }
}
